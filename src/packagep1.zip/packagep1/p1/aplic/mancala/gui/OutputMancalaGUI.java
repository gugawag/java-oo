/*
 * Desenvolvido para a disciplina Programacao 2
 * Curso de Bacharelado em Ci�ncia da Computa��o
 * Departamento de Sistemas e Computa��o
 * Universidade Federal da Para�ba
 *
 * Copyright (C) 2001 Universidade Federal da Para�ba.
 * N�o redistribuir sem permiss�o.
 */
package p1.aplic.mancala.gui;
import p1.aplic.mancala.jogo.*;
import java.util.*; 

/**
 *
 *
 * @author   Jacques Philippe Sauv�, jacques@dsc.ufpb.br
 * @version 1.0
 * <br>
 * Copyright (C) 2001 Universidade Federal da Para�ba.
 */
public class OutputMancalaGUI implements MancalaListener {
  public OutputMancalaGUI() {
    // constroi o tabuleiro
  }

  public void inicioDeJogo(MancalaEvent e) {
  }

  public void jogadorJogou(MancalaEvent e) {
  }

  public void fimDeJogo(MancalaEvent e) {
  }

  private void mostraTabuleiro(JogoMancala jogo) {
  }

  private void mostraJogador(Jogador jogador, JogoMancala jogo) {
  }
}

